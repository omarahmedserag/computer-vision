% directory to get the ball frame files
inputfolder = '_ball_frames';
imagefiles = dir(fullfile(inputfolder, 'frame-???.png'));
numberImages = length(imagefiles);
orientations = {'0','45','90','135'};
offsets = [0 1; -1 1; -1 0; -1 -1];
channels = {'Red', 'Green', 'Blue'};
featuresList = {'Contrast', 'Correlation', 'Energy'};

% initialize output table
outputTable = {};

% == Looping through all the images ==
for i = 1:numberImages
    basefileName = erase(imagefiles(i).name, '.png');
    rgbFile = fullfile(inputfolder, [basefileName, '.png']);
    maskFile = fullfile(inputfolder, [basefileName, '_indexed.png']);
    if ~exist(rgbFile, 'file') || ~exist(maskFile, 'file')
        fprintf('Skipping %s: Missing RGB or mask file\n', basefileName);
        continue;
    end
    rgb_ballImage = imread(rgbFile);
    mask_ballImage = imread(maskFile);

    for ballLabel = 1:3
        masking = mask_ballImage == ballLabel;
        if nnz(masking) == 0
            continue;
        end
       propsize = regionprops(masking, 'BoundingBox', 'Area');
for p = 1:length(propsize)
    if propsize(p).Area < 100  
        continue;
    end
    bbox = round(propsize(p).BoundingBox);
% looping through all channels and selects each ball color for masking in
% the best color channel that seperates it 
            for channel = 1:3
                channel_objname = channels{channel};
                channel_selection = rgb_ballImage(:,:,channel);
                object_ballregion = imcrop(channel_selection, bbox);
                maskingCrop = imcrop(masking, bbox);
                object_ballregion(maskingCrop == 0) = 0;

                % adding normalization
                validPixels = object_ballregion(maskingCrop > 0);
                if isempty(validPixels) || range(validPixels) < 2
                    continue; % Skip low-variation regions
                end
                minvalue = double(min(validPixels));
                maxvalue = double(max(validPixels));
                normalregion = uint8((double(object_ballregion) - minvalue) / (maxvalue - minvalue) * 31); % 32 levels
                normalregion(~maskingCrop) = 0;

                % glcm feature calculation
                glcmscalc = graycomatrix(normalregion, ...
                    'Offset', offsets, ...
                    'NumLevels', 32, ...
                    'Symmetric', true, ...
                    'GrayLimits', [0 31]);

                stats = graycoprops(glcmscalc, {'Contrast', 'Correlation', 'Energy'});

                for feature = 1:3
                    featureName = featuresList{feature};
                    values = stats.(featureName);

                    % normalizing contrast values for the feature is 'Contrast'
                    if strcmp(featureName, 'Contrast')
                        values = values / 31^2;  % Normalization for 32 levels
                    end

                    meanVal = mean(values);
                    rangeVal = range(values);

                    fprintf('Image: %s | Ball: %d | Channel: %s | Feature: %s | Mean: %.4f | Range: %.4f\n', ...
                        basefileName, ballLabel, channel_objname, featureName, meanVal, rangeVal);

                    outputTable(end+1,:) = {basefileName, ballLabel, channel_objname, 'All', featureName, 'Mean', meanVal};
                    outputTable(end+1,:) = {basefileName, ballLabel, channel_objname, 'All', featureName, 'Range', rangeVal};

                    for o = 1:4
                        outputTable(end+1,:) = {basefileName, ballLabel, channel_objname, orientations{o}, featureName, 'Value', values(o)};
                    end
                end
            end
        end
    end
end

% export texture feature values to excel 
outputval = [{'Image', 'Ball', 'Channel', 'Orientation', 'Feature', 'ValueType', 'Value'}; outputTable];
writecell(outputval, 'GLCM_Mean_Range_PerBall.csv');

% export full orientation texture feature values 
texturefeatureTable = [{'Image', 'Ball', 'Channel', 'Orientation', 'Feature', 'Value'}];

for i = 1:size(outputTable, 1)
    row = outputTable(i,:);
    if ~strcmp(row{6}, 'Value')  % Skip non-orientation rows
        continue;
    end
    % Adding orientation-specific value
    texturefeatureTable(end+1, :) = {row{1}, row{2}, row{3}, row{4}, row{5}, row{7}};
end

% Save values  to excel 
writecell(texturefeatureTable, 'texture_feature_calc.csv');
fprintf('\nSaved orientation-based texture features to texture_feature_calc.csv\n');
fprintf('\n=== Orientation-Based Texture Features ===\n');
for i = 2:size(texturefeatureTable,1)  % Skip header
    fprintf('Image: %s | Ball: %s | Channel: %s | Orientation: %s | Feature: %s | Value: %.4f\n', ...
        texturefeatureTable{i,1}, num2str(texturefeatureTable{i,2}), ...
        texturefeatureTable{i,3}, texturefeatureTable{i,4}, ...
        texturefeatureTable{i,5}, texturefeatureTable{i,6});
end

% boxplot the best selected feature for each color channel 
featuresToPlot = {'Contrast', 'Energy', 'Correlation'};  % R, G, B

figure;
for channel = 1:3
    subplot(3,1,channel);
    boxData = cell(1, 3); % Balls: 1, 2, 3
    for j = 1:3
        matchrows = strcmp(outputTable(:,3), channels{channel}) & ...
                    strcmp(outputTable(:,5), featuresToPlot{channel}) & ...
                    strcmp(outputTable(:,6), 'Mean') & ...
                    [outputTable{:,2}]' == j;
        boxData{j} = [outputTable{matchrows, 7}];
    end

    dataFlat = [boxData{1}, boxData{2}, boxData{3}]';
    groupFlat = [repmat(1, numel(boxData{1}), 1); ...
                 repmat(2, numel(boxData{2}), 1); ...
                 repmat(3, numel(boxData{3}), 1)];

    boxplot(dataFlat, groupFlat);
    title([channels{channel}, ' Channel - ', featuresToPlot{channel}, ' (Boxplot)']);
    ylabel('Feature Value');
    xticklabels({'Ball 1', 'Ball 2', 'Ball 3'});
end

% KDE density plot for the three rgb Channel
figure;
for channel = 1:3
    subplot(3,1,channel);
    hold on;
    for j = 1:3
        matchrows = strcmp(outputTable(:,3), channels{channel}) & ...
                    strcmp(outputTable(:,5), featuresToPlot{channel}) & ...
                    strcmp(outputTable(:,6), 'Mean') & ...
                    [outputTable{:,2}]' == j;
        vals = [outputTable{matchrows,7}];
        if ~isempty(vals) && length(vals) > 5
            [feature, xi] = ksdensity(vals);
            plot(xi, feature, 'DisplayName', ['Ball ', num2str(j)], 'LineWidth', 1.5);
        end
    end
    hold off;
    title([channels{channel}, ' Channel - ', featuresToPlot{channel}, ' (Density Plot)']);
    xlabel('Feature Value'); ylabel('Density');
    legend('show');
    grid on;
end

% load excel file for bar charts
datav = readtable('GLCM_Mean_Range_PerBall.csv');
datav.Feature = string(datav.Feature);
datav.Channel = string(datav.Channel);
datav.Ball = categorical(datav.Ball);

meandata = datav(strcmp(datav.ValueType, 'Mean'), :);
rangedata = datav(strcmp(datav.ValueType, 'Range'), :);

features = unique(meandata.Feature);
channelsli = unique(meandata.Channel);
balls = {'1', '2', '3'};
ballLabels = {'Tennis', 'Soccerball', 'Football'};

% mean feature value for each bar chart
figure('Name', 'Mean Feature Values', 'Position', [100 100 1200 600]);
for i = 1:length(features)
    subplot(1, length(features), i);
    values = NaN(length(balls), length(channelsli));
    for j = 1:length(balls)
        for channel = 1:length(channelsli)
            rowsf = strcmp(meandata.Feature, features(i)) & ...
                   strcmp(meandata.Channel, channelsli(channel)) & ...
                   double(meandata.Ball) == str2double(balls{j});
            if any(rowsf)
                values(j, channel) = mean(meandata.Value(rowsf));
            end
        end
    end
    bar(values);
    title(['mean - ', features(i)]);
    ylabel('mean value');
    set(gca, 'xticklabel', ballLabels);
    legend(channelsli, 'Location', 'best');
    grid on;
end

% range feature value for each bar chart
figure('Name', 'Range Feature Values', 'Position', [100 100 1200 600]);
for i = 1:length(features)
    subplot(1, length(features), i);
    values = NaN(length(balls), length(channelsli));
    for j = 1:length(balls)
        for channel = 1:length(channelsli)
            rowsf = strcmp(rangedata.Feature, features(i)) & ...
                   strcmp(rangedata.Channel, channelsli(channel)) & ...
                   double(rangedata.Ball) == str2double(balls{j});
            if any(rowsf)
                values(j, channel) = mean(rangedata.Value(rowsf));
            end
        end
    end
    bar(values);
    title(['range - ', features(i)]);
    ylabel('range value');
    set(gca, 'XTickLabel', ballLabels);
    legend(channelsli, 'Location', 'best');
    grid on;
end

% density plot for each feature for each of the three channels
featurenames = {'Contrast', 'Energy', 'Correlation'};
channelcolors = {'r', 'g', 'b'};
channelList = {'Red', 'Green', 'Blue'};
% looping for selecting  rows based on the current rgb channel,  texture feature, and ball label value,
for feature = 1:length(featurenames)
    figure('Name', [featurenames{feature}, ' - All Channels'], 'Position', [200, 200, 900, 500]);
    tiledlayout(1, 3, 'Padding', 'compact');

    for channel = 1:3
        nexttile;
        hold on;
        for j = 1:3
            matchrows = strcmp(outputTable(:,3), channelList{channel}) & ...
                        strcmp(outputTable(:,5), featurenames{feature}) & ...
                        strcmp(outputTable(:,6), 'Mean') & ...
                        [outputTable{:,2}]' == j;
            vals = [outputTable{matchrows,7}];
            if ~isempty(vals) && length(vals) > 5
                [fvals, xvals] = ksdensity(vals);
                plot(xvals, fvals, 'LineWidth', 1.5, 'DisplayName', ['Ball ', num2str(j)]);
            end
        end
        title([channelList{channel}, ' Channel']);
        xlabel('Feature Value'); ylabel('Density');
        legend('show');
        grid on;
    end

    sgtitle([featurenames{feature}, ' feature - all channels']);
end