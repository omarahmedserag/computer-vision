close all; clear; clc;

% specifying the path of the Folder and the File 
img_folder = 'ball_frames'; % the directory Path to folder
filname = dir(fullfile(img_folder, '*.png')); % search for original rgb images 
t_images = numel(filname); % Total number of images

% the Ball value Labels -- the ball labels extracted using techniques based on area and aspect ratio
% Labels {1} =(Tennis), Labels {2}= (Soccerball), Labels {3}= (American Football)
% Allocate the feature storage memory and calculate max ball objects each frame
maximuim_objects_per_ballframe = 3; % number of balls to allocate the maximum
shape_ball_Features = zeros(t_images * maximuim_objects_per_ballframe, 6); % [frame, label, solidity, noncompactness, circularity, eccentricity]
shape_balls_indx = 0; % initial index for the shape balls features

% Processing per Frame
for n = 1:t_images
    % to get the RGB image and Ground-Truth Filenames
    f = fullfile(img_folder, filname(n).name);
    if ~exist(f, 'file')
        fprintf('Frame %d: the RGB file %s not found, skipping...\n', n, f);
        continue;
    end
    ball_image = imread(f); % the rgb image file
    % to extract the frame number from the file
    ball_frameNumber = regexp(filname(n).name, 'frame-(\d+)_rgb\.png', 'tokens');
    if isempty(ball_frameNumber)
        fprintf('Frame %d: Invalid filename format (%s), skipping...\n', n, filname(n).name);
        continue;
    end
    ball_frameNumber = ball_frameNumber{1}{1};
    % a check for the ground truth file
    grt_FileName = sprintf('frame-%s_indexed.png', ball_frameNumber);
    grt_FilePath = fullfile(img_folder, grt_FileName);
    if ~exist(grt_FilePath, 'file')
        fprintf('Frame %s: the ground-truth file %s not found, skipping...\n', ball_frameNumber, grt_FileName);
        continue;
    end

    % to load ground-truth Image
    grt_tr = imread(grt_FilePath); % indexed Ground-Truth
    fprintf('Processing frame %s...\n', ball_frameNumber);

    % extract connected components objects from the image using their geometrical properties
    cc_obj = bwconncomp(grt_tr);
    stats = regionprops(cc_obj, 'BoundingBox', 'Area', 'Perimeter', 'ConvexArea', ...
                      'MajorAxisLength', 'MinorAxisLength', 'PixelList');
    if isempty(stats)
        fprintf('Frame %s: No region found, skipping...\n', ball_frameNumber);
        continue;
    end

    % Process Each Ball
    for ball = 1:cc_obj.NumObjects
        % Extract the ball region
        bbox_val = stats(ball).BoundingBox;
        area_val = stats(ball).Area;
        ball_mask = false(size(grt_tr));
        ball_mask(cc_obj.PixelIdxList{ball}) = true;

        % Compute perimeter using object boundaries
        boundary = bwboundaries(ball_mask);
        if isempty(boundary)
            fprintf('Frame %s, Ball %d: Boundary not correct\n', ball_frameNumber, ball);
            continue;
        end
        boundary_points = boundary{1}; % [row, col]
        diffs = diff(boundary_points, 1, 1);
        dists = sqrt(sum(diffs.^2, 2));
        perimeter_val = sum(dists);
        convex_Area = stats(ball).ConvexArea;
        majoraxis_ball_length = stats(ball).MajorAxisLength;
        minoraxis_ball_length = stats(ball).MinorAxisLength;

        % Skip very small regions
        if area_val < 100
            fprintf('Frame %s, Ball %d: Area size too small (%d), skipping...\n', ball_frameNumber, ball, area_val);
            continue;
        end

        % Assign label based on area and aspect ratio
        aspect_Ratio = minoraxis_ball_length / majoraxis_ball_length;
        if area_val < 500 && aspect_Ratio > 0.9
            label_value = 1; % Tennis
        elseif area_val > 1350 && aspect_Ratio < 0.7
            label_value = 3; % American Football
        else
            label_value = 2; % Soccerball
        end

        % Compute eccentricity with adding ellipse fitting
        if majoraxis_ball_length <= 0 || minoraxis_ball_length <= 0
            eccentricity_value = 0;
            fprintf('Frame %s, Label %d: Invalid axis lengths, setting Eccentricity to 0.\n', ball_frameNumber, label_value);
        else
            % fitting an ellipse to the pixels in the ball's image
            pixel_List = stats(ball).PixelList;
            x = pixel_List(:,1);
            y = pixel_List(:,2);
            [a, b_ellipse, ~] = fit_ellipse(x, y);
            if a > 0 && b_ellipse > 0
                majoraxis_ball_length = max(a, b_ellipse);
                minoraxis_ball_length = min(a, b_ellipse);
            else
                fprintf('Frame %s, Label %d: ellipse fitting failed using regionprops values.\n', ball_frameNumber, label_value);
            end

            % to check if minoraxisLength <= MajorAxisLength
            if minoraxis_ball_length > majoraxis_ball_length
                tempaxises = majoraxis_ball_length;
                majoraxis_ball_length = minoraxis_ball_length;
                minoraxis_ball_length = tempaxises;
            end

            % compute eccentricity
            eccentricity_value = sqrt(1 - (minoraxis_ball_length / majoraxis_ball_length)^2);
            if ~isreal(eccentricity_value) || isnan(eccentricity_value)
                eccentricity_value = 0;
                fprintf('Frame %s, Label %d: Invalid eccentricity, setting to 0.\n', ball_frameNumber, label_value);
            end
        end

        solidity_value = area_val / convex_Area;
        noncompactness_value = (perimeter_val^2) / (4 * pi * area_val);
        circularity_ball = (4 * pi * area_val) / (perimeter_val^2);

        % to store the ball shape features in an array
        shape_balls_indx = shape_balls_indx + 1;
        shape_ball_Features(shape_balls_indx, :) = [str2double(ball_frameNumber), label_value, solidity_value, noncompactness_value, circularity_ball, eccentricity_value];
    end
end

% trim the feature arrays to take only valuable shape feature array
shape_ball_Features = shape_ball_Features(1:shape_balls_indx, :);

% show the feature values for every ball
if isempty(shape_ball_Features)
    warning('No features computed. Check your images and/or labels.');
else
    % shape features
    fprintf('\n= Ball Shape Features =\n');
    fprintf('Frame --- Label --- Solidity ---- Non-Compactness --- Circularity --- Eccentricity\n');
    fprintf('----------------------\n');
    for i = 1:size(shape_ball_Features, 1)
        fprintf('%5d | %5d | %8.4f | %15.4f | %11.4f | %12.4f\n', ...
               shape_ball_Features(i, 1), shape_ball_Features(i, 2), shape_ball_Features(i, 3), ...
               shape_ball_Features(i, 4), shape_ball_Features(i, 5), shape_ball_Features(i, 6));
    end
end

% shape feature histograms (1 Figure with 4 Subplots)
if ~isempty(shape_ball_Features)
    figure('Name', 'Shape Features Histograms', 'Color', 'w');
    ti = tiledlayout(2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
    featurenames_Shape = {'Solidity', 'Non-Compactness', 'Circularity', 'Eccentricity'};
    colors_Shape = {'b', 'r', 'g'}; % Blue for Tennis, Red for Soccerball, Green for American Football

    for i = 1:4
        nexttile;
        hold on;
        % tennis ball (Label 1)
        data_1 = shape_ball_Features(shape_ball_Features(:, 2) == 1, i+2);
        if ~isempty(data_1)
            histogram(data_1, 'FaceColor', colors_Shape{1}, 'EdgeColor', 'k', 'FaceAlpha', 0.5, 'BinMethod', 'auto');
        end
        % soccerball (Label 2)
        data_2 = shape_ball_Features(shape_ball_Features(:, 2) == 2, i+2);
        if ~isempty(data_2)
            histogram(data_2, 'FaceColor', colors_Shape{2}, 'EdgeColor', 'k', 'FaceAlpha', 0.5, 'BinMethod', 'auto');
        end
        % american Football (Label 3)
        data_3 = shape_ball_Features(shape_ball_Features(:, 2) == 3, i+2);
        if ~isempty(data_3)
            histogram(data_3, 'FaceColor', colors_Shape{3}, 'EdgeColor', 'k', 'FaceAlpha', 0.5, 'BinMethod', 'auto');
        end
        hold off;

        title(['\bf' featurenames_Shape{i}], 'FontSize', 12);
        xlabel('\bfValue', 'FontSize', 10);
        ylabel('\bfFrequency', 'FontSize', 10);
        legend('Tennis', 'Soccerball', 'American Football', 'Location', 'best');
        grid on;
        set(gca, 'FontSize', 9);
    end
    title(ti, '\bf histograms for shape features by ball type', 'FontSize', 12);   
end

% plotting shape features
if ~isempty(shape_ball_Features)
    fprintf('\n shape features matrix size: %d rows, %d columns\n', size(shape_ball_Features, 1), size(shape_ball_Features, 2));

    figure('Name', 'Shape Features', 'Color', 'w');
    ti = tiledlayout(2, 2, 'Padding', 'compact', 'TileSpacing', 'compact');
    featurenames_Shape = {'Solidity', 'Non-Compactness', 'Circularity', 'Eccentricity'};

    for i = 1:4
        nexttile;
        boxplot(shape_ball_Features(:, i+2), shape_ball_Features(:, 2), ...
              'Colors', 'k', 'Symbol', 'o', 'Widths', 0.5, 'Whisker', 1.5);
        title(['\bf' featurenames_Shape{i}], 'FontSize', 13);
        xlabel('\bf ball Label', 'FontSize', 11);
        ylabel(['\bf' featurenames_Shape{i}], 'FontSize', 11);
        grid on;
        set(gca, 'FontSize', 10);
    end
    title(ti, '\bf shape features for every ball type (All Frames)', 'FontSize', 16);
end

% nested function for fitting the ellipse
function [a_axises, b_axises, theta_v] = fit_ellipse(x_val, y_val)
    % applying least squares fitting of an ellipse to 2D points
    % returning semi-major axis (a), semi-minor axis (b), and orientation angle (theta)
    
    % default return values if the fitting method fails
    a_axises = 0;
    b_axises = 0;
    theta_v = 0;
    
    % to check for sufficient points
    if length(x_val) < 6 % Need at least 6 points for reliable fitting
        fprintf(' not enough points (%d) to fit an ellipse.\n', length(x_val));
        return;
    end
    
    % center the data points
    x_val = x_val - mean(x_val);
    y_val = y_val - mean(y_val);
    
    % design matrix for least squares
    D_val = [x_val.^2, x_val.*y_val, y_val.^2, x_val, y_val, ones(size(x_val))];
    
    % scatter matrix
    S_val = D_val' * D_val;
    
    % constraint matrix (for ellipse-specific constraint: 4ac - b^2 = 1)
    C = zeros(6, 6);
    C(1,3) = 2; C(3,1) = 2; C(2,2) = -1;
    
    % solving the eigenvalues 
    try
        [gevec, geval] = eig(S_val, C);
        geval = diag(geval);
        valid_evals = geval > 0 & isfinite(geval);
        if ~any(valid_evals)
            fprintf(' No positive finite eigenvalue .\n');
            return;
        end
        [~, idx] = min(geval(valid_evals));
        idx = find(valid_evals, idx, 'first');
        coeffs = gevec(:, idx);
    catch
        fprintf(' Eigenvalue computation failed.\n');
        return;
    end
    
    % getting ellipse main parameters (ax^2 + bxy + cy^2 + dx + ey + f = 0)
    a_coeff = coeffs(1);
    b_coeff = coeffs(2);
    c_coeff = coeffs(3);
    d_coeff = coeffs(4);
    e_coeff = coeffs(5);
    f_coeff = coeffs(6);
    
    % compute center (h, k)
    denom = b_coeff^2 - 4*a_coeff*c_coeff;
    if abs(denom) < 1e-10
        fprintf(' Invalid ellipse parameters (denom ≈ 0).\n');
        return;
    end
    h = (2*c_coeff*d_coeff - b_coeff*e_coeff) / denom;
    k = (2*a_coeff*e_coeff - b_coeff*d_coeff) / denom;
    
    % computing semi-axes
    num_coff = 2*(a_coeff*e_coeff^2 + c_coeff*d_coeff^2 - b_coeff*d_coeff*e_coeff + (b_coeff^2 - 4*a_coeff*c_coeff)*f_coeff);
    denom1_coff = (b_coeff^2 - 4*a_coeff*c_coeff) * (sqrt((a_coeff - c_coeff)^2 + b_coeff^2) - (a_coeff + c_coeff));
    denom2_coff = (b_coeff^2 - 4*a_coeff*c_coeff) * (-sqrt((a_coeff - c_coeff)^2 + b_coeff^2) - (a_coeff + c_coeff));
    
    if abs(denom1_coff) < 1e-10 || abs(denom2_coff) < 1e-10
        fprintf(' Invalid semi-axes calculation.\n');
        return;
    end
    
    semi_a_obj = sqrt(num_coff / denom1_coff);
    semi_b_obj = sqrt(num_coff / denom2_coff);
    
    % ensure real values
    if ~isreal(semi_a_obj) || ~isreal(semi_b_obj) || isnan(semi_a_obj) || isnan(semi_b_obj)
        fprintf(' Non-real /nan semi-axes.\n');
        return;
    end
    % to assign semi-major and semi-minor axes
    a_axises = max(semi_a_obj, semi_b_obj);
    b_axises = min(semi_a_obj, semi_b_obj);
    
    % compute orientation angle
    if abs(b_coeff) < 1e-10
        if a_coeff < c_coeff
            theta_v = 0;
        else
            theta_v = pi/2;
        end
    else
        theta_v = atan2(c_coeff - a_coeff, b_coeff) / 2;
    end
    % conditions for testing the calculation results
    if a_axises <= 0 || b_axises <= 0 || isnan(a_axises) || isnan(b_axises)
        fprintf(' incorrect semi-axes (a or b <= 0 or nan).\n');
        a_axises = 0;
        b_axises = 0;
        theta_v = 0;
    end
end