function t3()

    % to Declare  the global variables for ground truth
    global x_true y_true;

    % Load data
    x_TR = csvread('x.csv');
    y_TR = csvread('y.csv');
    u_val = csvread('na.csv');
    v_val = csvread('nb.csv');

    % to assign ground truth to global variables
    x_true = x_TR;
    y_true = y_TR;

    % to   calculate noise (for informational purposes)
    nx = u_val - x_TR;
    ny = v_val - y_TR;
    mean_nx = mean(nx);
    std_nx = std(nx);
   

    mean_ny = mean(ny);
    std_ny = std(ny);
    fprintf('mean of nx: %.4f, the standard deviation value of nx: %.4f\n', mean_nx, std_nx);
    fprintf('mean of ny: %.4f, the standard deviation of ny value: %.4f\n', mean_ny, std_ny);

    %  to plot the  histograms of noise (Figure 1)
    figure(1);
    subplot(1, 2, 1);
    histogram(nx, 30, 'Normalization', 'pdf');
    title('histogram of nx');
    xlabel('noise in x (nx)');
    ylabel('probability density');

    subplot(1, 2, 2);
    histogram(ny, 30, 'Normalization', 'pdf');
    title('histogram of ny');
    xlabel('Noise in y (ny)');
    ylabel('Probability density');

    % TO Combine THE noisy coordinates into z
    z = [u_val; v_val];

    %  TO Define tunable parameter values AFFECTING MODEL PREDICITON TO THE
    %  REAL TRAJECTORY
    q_scales_r = [0.1, 1, 3, 5, 10, 20, 25, 30, 40, 50]; % For Q
    r_scales_num = [0.1, 1, 3, 5, 10, 15, 20]; % For R
    initial_states_num = struct( ...
        'default', [0; 0; 0; 0], ... % Default: [x, vx, y, vy] = [0, 0, 0, 0]
        'optimized', [] ... % Will be computed
    );
    initial_Ps = struct( ...
        'default', [], ... % Will be set to Q
        'optimized', diag([100, 10, 100, 10]) ... % High uncertainty in position
    );

    %  TO Compute optimized initial state
    dt = 0.5;
    vx_init = (z(1,2) - z(1,1)) / dt; % Initial x-velocity
    vy_init = (z(2,2) - z(2,1)) / dt; % Initial y-velocity
    initial_states_num.optimized = [z(1,1); vx_init; z(2,1); vy_init];

    %  TO FIND THE Fixed values for other parameters when testing one
    fixed_q_scale_val = 1; % Fixed value for Q when testing others
    fixed_r_scale_t = 1; % Fixed value for R when testing others
    fixed_x_init = initial_states_num.optimized; % Fixed to optimized state
    fixed_P_init_stat = initial_Ps.optimized; % Fixed to optimized P

    % TO THE  Number of time steps
    Num = size(z, 2);
    
    %  TO FIND THE Test 1: Effect of q_scale (Q)
    rmse_q_val_c = zeros(length(q_scales_r), Num);
    for i = 1:length(q_scales_r)
        q = q_scales_r(i);
        fprintf(' the Testing q_scale values = %.1f\n', q);
        [~, ~, rmse_history] = kTracking(z, q, fixed_r_scale_t, fixed_x_init, fixed_P_init_stat);
        rmse_q_val_c(i, :) = rmse_history;
    end

    % Test 2 TO FIND THE  Effect of r_scale (R)
    rmse_r_val = zeros(length(r_scales_num), Num);
    for i = 1:length(r_scales_num)
        r = r_scales_num(i);
        fprintf(' the Testing r_scale values = %.1f\n', r);
        [~, ~, rmse_history] = kTracking(z, fixed_q_scale_val, r, fixed_x_init, fixed_P_init_stat);
        rmse_r_val(i, :) = rmse_history;
    end

    % Test 3 TO FIND THE  Effect of initial state (x)
    initial_state_names_st = fieldnames(initial_states_num);
    rmse_x_ = zeros(length(initial_state_names_st), Num);
    for i = 1:length(initial_state_names_st)
        name_c_v = initial_state_names_st{i};
        x_init_state = initial_states_num.(name_c_v);
        fprintf(' the Testing initial state: %s\n', name_c_v);
        [~, ~, rmse_history] = kTracking(z, fixed_q_scale_val, fixed_r_scale_t, x_init_state, fixed_P_init_stat);
        rmse_x_(i, :) = rmse_history;
    end

    % Test 4 TO FIND THE  Effect of initial covariance (P)
    initial_P_names_st = fieldnames(initial_Ps);
    rmse_P = zeros(length(initial_P_names_st), Num);
    for i = 1:length(initial_P_names_st)
        name_c_v = initial_P_names_st{i};
        P_init_v = initial_Ps.(name_c_v);
        fprintf(' the Testing initial P: %s\n', name_c_v);
        [~, ~, rmse_history] = kTracking(z, fixed_q_scale_val, fixed_r_scale_t, fixed_x_init, P_init_v);
        rmse_P(i, :) = rmse_history;
    end

    % TO Plot THE  convergence speed for each parameter
    % Plot 1 TO PLOT THE  q_scale
    figure(2);
    for i = 1:length(q_scales_r)
        plot(1:Num, rmse_q_val_c(i, :), 'LineWidth', 2, 'DisplayName', sprintf('q_scale = %.1f', q_scales_r(i)));
        hold on;
    end
    hold off;
    legend('show');
    title(' the Convergence of Speed  Effect of q_scale (Q)');
    xlabel('Time Step');
    ylabel('RMSE');
    grid on;

    %  TO Plot  THE 2 r_scale
    figure(3);
    for i = 1:length(r_scales_num)
        plot(1:Num, rmse_r_val(i, :), 'LineWidth', 2, 'DisplayName', sprintf('r_scale = %.1f', r_scales_num(i)));
        hold on;
    end
    hold off;
    legend('show');
    title(' the Convergence of Speed  Effect of r_scale (R)');
    xlabel('Time Step');
    ylabel('RMSE');
    grid on;

    %  TO Plot 3 THE  Initial state
    figure(4);
    for i = 1:length(initial_state_names_st)
        plot(1:Num, rmse_x_(i, :), 'LineWidth', 2, 'DisplayName', sprintf('Initial State: %s', initial_state_names_st{i}));
        hold on;
    end
    hold off;
    legend('show');
    title(' the Convergence Speed  Effect of  the Initial State');
    xlabel('Time Step');
    ylabel('RMSE');
    grid on;

    %  TO Plot 4  THE Initial covariance
    figure(5);
    for i = 1:length(initial_P_names_st)
        plot(1:Num, rmse_P(i, :), 'LineWidth', 2, 'DisplayName', sprintf('Initial P: %s', initial_P_names_st{i}));
        hold on;
    end
    hold off;
    legend('show');
    title(' the Convergence Speed  Effect of the  Initial Covariance (P)');
    xlabel('Time Step');
    ylabel('RMSE');
    grid on;

    % TO  Find best overall parameters (for Part ii)
    best_rmse_x_v = Inf;
    best_rmse_y_v = Inf;
    best_q_scale_v = 0;
    best_r_scale_v = 0;
    best_x_predict_v = [];
    best_y_predict_v = [];

    % Calculate RMSE for noisy coordinates
    rmse_nx_b = sqrt(mean((u_val - x_TR).^2));
    rmse_ny_v = sqrt(mean((v_val - y_TR).^2));
    fprintf('\n  the rmse of the  noisy x: %.4f\n', rmse_nx_b);
    fprintf('rmse of the  noisy y: %.4f\n', rmse_ny_v);

    %  to Loop over q_scale and r_scale to find best parameters
    for q = q_scales_r
        for r = r_scales_num
            fprintf('Testing with different q = %.1f, r = %.1f\n', q, r);
            [x_predict, y_predict] = kTracking(z, q, r, fixed_x_init, fixed_P_init_stat);
            rmse_x_predict = sqrt(mean((x_predict - x_TR).^2));
            rmse_y_predict = sqrt(mean((y_predict - y_TR).^2));
            fprintf('the rmse of estimated value x: %.4f\n', rmse_x_predict);
            fprintf('the rmse of estimated  value y: %.4f\n', rmse_y_predict);
            
            combined_rmse = (rmse_x_predict + rmse_y_predict) / 2;
            if combined_rmse < (best_rmse_x_v + best_rmse_y_v) / 2
                best_rmse_x_v = rmse_x_predict;
                best_rmse_y_v = rmse_y_predict;
                best_q_scale_v = q;
                best_r_scale_v = r;
                best_x_predict_v = x_predict;
                best_y_predict_v = y_predict;
            end
        end
    end

    % Calculate RMSE at each time step for noisy and estimated coordinates
    rmse_nx_tr = sqrt((u_val - x_TR).^2); %  the RMSE each time step for noisy x
    rmse_ny_tr = sqrt((v_val - y_TR).^2); % RMSE each time step for noisy y
    rmse_x_predict_tr = sqrt((best_x_predict_v - x_TR).^2); % RMSE each time step for estimated x
    rmse_y_predict_tr = sqrt((best_y_predict_v - y_TR).^2); % RMSE each time step for estimated y

    % to  calculate the  mean and standard deviation of  the rMSE
    mean_rmse_nx = mean(rmse_nx_tr);
    std_rmse_nx = std(rmse_nx_tr);
    mean_rmse_ny = mean(rmse_ny_tr);
    std_rmse_ny = std(rmse_ny_tr);
    mean_rmse_x_predict = mean(rmse_x_predict_tr);
    std_rmse_x_predict = std(rmse_x_predict_tr);
    mean_rmse_y_predict = mean(rmse_y_predict_tr);
    std_rmse_y_predict = std(rmse_y_predict_tr);
 
    % Report best parameters and RMSE statistics
    fprintf('\n  the best parameters forq_scale = %.1f, r_scale = %.1f\n', best_q_scale_v, best_r_scale_v);
    fprintf(' best rmse for estimated x: %.4f\n', best_rmse_x_v);
    fprintf('best rmse for estimated y: %.4f\n', best_rmse_y_v);
    fprintf('\n rmse formula to calculate the rmse = sqrt((1/N) * sum((predicted - actual)^2))\n');
    fprintf(' the mean RMSE of noisy value of x: %.4f, Standard Deviation RMSE of noisy x: %.4f\n', mean_rmse_nx, std_rmse_nx);
    fprintf('mean rmse of noisy y: %.4f, Standard Deviation RMSE of noisy y: %.4f\n', mean_rmse_ny, std_rmse_ny);
    fprintf('mean rmse of estimated of  x: %.4f, Standard Deviation RMSE of estimated x: %.4f\n', mean_rmse_x_predict, std_rmse_x_predict);
    fprintf('mean rmse of estimated of  y: %.4f, Standard Deviation RMSE of estimated y: %.4f\n', mean_rmse_y_predict, std_rmse_y_predict);

    % Plot the trajectories using the best parameters (Figure 6, for Part i)
    figure(6);
    plot(x_TR, y_TR, '--g', 'DisplayName', 'Real [x, y]');
    hold on;
    plot(u_val, v_val, '+b', 'DisplayName', 'Noisy [na, nb]');
    plot(best_x_predict_v, best_y_predict_v, '--r', 'DisplayName', 'Estimated [x^*, y^*]');
    hold on;
    plot(x_TR, y_TR, '--g', 'HandleVisibility', 'off');
    hold off;
    legend('show');
    title(' the Trajectories: real, noisy, and estimated');
    xlabel('x');
    ylabel('y');

    % to  Plot RMSE over time for noisy and estimated coordinates (Figure 7)
    figure(7);
    plot(1:Num, rmse_nx_tr, 'b-', 'LineWidth', 2, 'DisplayName', 'Noisy x RMSE');
    hold on;
    plot(1:Num, rmse_ny_tr, 'b--', 'LineWidth', 2, 'DisplayName', 'Noisy y RMSE');
    plot(1:Num, rmse_x_predict_tr, 'r-', 'LineWidth', 2, 'DisplayName', 'Estimated x RMSE');
    plot(1:Num, rmse_y_predict_tr, 'r--', 'LineWidth', 2, 'DisplayName', 'Estimated y RMSE');
    hold off;
    legend('show');
    title(' the RMSE Over Time:  the Noisy vs Estimated Coordinates');
    xlabel('Time Step');
    ylabel('RMSE');
    grid on;
end

function [x_e, P_e] = kUpdate(x, P, H, R, z)
    % Update step of Kalman filter.
    S = H * P * H' + R;
    K = P * H' * inv(S);
    zp = H * x;
    
%gate = (z - zp)' * inv(S) * (z - zp);
%if gate > 9.21
 %warning('Observation outside validation gate');
%x_e = x;
 %P_e = P;
 %return
%end
    x_e = x + K * (z - zp);
    P_e = P - K * S * K';
end

function [xp, Pp] = kPredict(x, P, F, Q)
    % Prediction step of Kalman filter.
    xp = F * x;
    Pp = F * P * F' + Q;
end

function [px, py, rmse_history_mem] = kTracking(z, q_scale, r_scale, x_init, P_init)
    %  to Track  the  target with a Kalman filter
    % z:  to use camera as a variable z to the observation vector
    % q_scale:  the scalar variable  to scale the Q matrix
    % r_scale: scalar to scale the R matrix
    % x_init:  the initial state vector
    % P_init:  the initial state values for the   covariance- matrix (if it is  empty, defaults to Q)
    % Returns:  the estimated of the  positions (px, py) and RMSE of the  history over time
    global x_true y_true; %  the ground truth for rmse calculation
    dt = 0.5;
    N = size(z, 2);
    F = [1 dt 0 0; 0 1 0 0; 0 0 1 dt; 0 0 0 1];
    
    Q_base = [0.16 0 0 0; 0 0.36 0 0; 0 0 0.16 0; 0 0 0 0.36];
    R_base = [0.25 0; 0 0.255];
    
    if nargin < 2
        q_scale = 1;
    end
    if nargin < 3
        r_scale = 1;
    end
    
    Q_val = q_scale * Q_base;
    R_val = r_scale * R_base;
    
    H_val = [1 0 0 0; 0 0 1 0];
    x_1 = x_init;
    if isempty(P_init)
        P_1 = Q_val;
    else
        P_1 = P_init;
    end
    s = zeros(4, N);
    rmse_history_mem = zeros(1, N);
    
    for i = 1:N
        [x_p, P_p] = kPredict(x_1, P_1, F, Q_val);
        [x_1, P_1] = kUpdate(x_p, P_p, H_val, R_val, z(:,i));
        s(:,i) = x_1;
        
        x_pred1 = s(1,i);
        y_pred1 = s(3,i);
        rmse_history_mem(i) = sqrt(mean(([x_pred1; y_pred1] - [x_true(i); y_true(i)]).^2));
    end
    px = s(1,:);
    py = s(3,:);
end
